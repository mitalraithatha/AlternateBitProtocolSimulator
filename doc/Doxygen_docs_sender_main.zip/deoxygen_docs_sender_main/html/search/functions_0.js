var searchData=
[
  ['applicationgen_20',['ApplicationGen',['../class_application_gen.html#ab06e8466334ad5234cf502fb6198c1e9',1,'ApplicationGen::ApplicationGen()=default'],['../class_application_gen.html#a68ccf7ca4e326ea883a5bd7eb488c66c',1,'ApplicationGen::ApplicationGen(const char *file_path)']]]
];
