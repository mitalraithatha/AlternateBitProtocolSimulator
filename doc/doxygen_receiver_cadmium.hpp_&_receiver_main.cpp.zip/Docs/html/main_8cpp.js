var main_8cpp =
[
    [ "input", "structinput.html", null ],
    [ "output", "structoutput.html", null ],
    [ "ApplicationGen", "class_application_gen.html", "class_application_gen" ],
    [ "RECEIVER_TEST_INPUT", "main_8cpp.html#aed98036dc8d4749f0e341d87e39245cc", null ],
    [ "RECEIVER_TEST_OUTPUT", "main_8cpp.html#ad6ac9f6ae200580db606b5cf669fd07f", null ],
    [ "hclock", "main_8cpp.html#a49149f534c2366ae290d9fa7131c8dc0", null ],
    [ "TIME", "main_8cpp.html#a3893724880e0bfd3cabf4fceb0d0fb5d", null ],
    [ "main", "main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ]
];