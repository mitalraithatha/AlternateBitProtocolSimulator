var annotated_dup =
[
    [ "ApplicationGen", "class_application_gen.html", "class_application_gen" ],
    [ "input", "structinput.html", null ],
    [ "output", "structoutput.html", null ],
    [ "Receiver", "class_receiver.html", "class_receiver" ],
    [ "receiver_defs", "structreceiver__defs.html", [
      [ "input", "structreceiver__defs_1_1input.html", null ],
      [ "output", "structreceiver__defs_1_1output.html", null ]
    ] ]
];