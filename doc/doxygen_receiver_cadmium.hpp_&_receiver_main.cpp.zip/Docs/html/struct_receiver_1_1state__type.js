var struct_receiver_1_1state__type =
[
    [ "acknowledgement_number", "struct_receiver_1_1state__type.html#a0d69373166f18f6852e6121809b66551", null ],
    [ "sending", "struct_receiver_1_1state__type.html#a07a73a253544ee613b92b04d1bf861f9", null ]
];