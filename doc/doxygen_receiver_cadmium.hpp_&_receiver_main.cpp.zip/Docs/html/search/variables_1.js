var searchData=
[
  ['preparation_5ftime_34',['PREPARATION_TIME',['../class_receiver.html#a547c2b91b5928ef700f291748bd6113b',1,'Receiver']]]
];
