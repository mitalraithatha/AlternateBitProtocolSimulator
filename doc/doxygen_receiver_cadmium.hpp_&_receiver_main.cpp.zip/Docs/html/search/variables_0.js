var searchData=
[
  ['acknowledgement_5fnumber_33',['acknowledgement_number',['../struct_receiver_1_1state__type.html#a0d69373166f18f6852e6121809b66551',1,'Receiver::state_type']]]
];
