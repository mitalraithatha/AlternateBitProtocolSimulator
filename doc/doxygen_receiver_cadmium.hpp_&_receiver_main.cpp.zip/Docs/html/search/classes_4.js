var searchData=
[
  ['state_5ftype_22',['state_type',['../struct_receiver_1_1state__type.html',1,'Receiver']]]
];
