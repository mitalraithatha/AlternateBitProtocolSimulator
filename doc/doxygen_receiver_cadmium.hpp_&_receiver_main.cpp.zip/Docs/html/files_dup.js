var files_dup =
[
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "receiver_cadmium.hpp", "receiver__cadmium_8hpp.html", [
      [ "receiver_defs", "structreceiver__defs.html", [
        [ "input", "structreceiver__defs_1_1input.html", null ],
        [ "output", "structreceiver__defs_1_1output.html", null ]
      ] ],
      [ "output", "structreceiver__defs_1_1output.html", null ],
      [ "input", "structreceiver__defs_1_1input.html", null ],
      [ "Receiver", "class_receiver.html", "class_receiver" ],
      [ "state_type", "struct_receiver_1_1state__type.html", "struct_receiver_1_1state__type" ]
    ] ]
];